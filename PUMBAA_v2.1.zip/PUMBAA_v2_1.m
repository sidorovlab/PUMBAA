classdef PUMBAA_v2_1 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                      matlab.ui.Figure
        Panel                         matlab.ui.container.Panel
        RemainingBehaviorsLabel       matlab.ui.control.Label
        Active                        matlab.ui.control.TextArea
        ActiveFileLabel               matlab.ui.control.Label
        StandardizebySexButton        matlab.ui.control.Button
        SelectedBehaviorsLabel        matlab.ui.control.Label
        ReducedLB                     matlab.ui.control.ListBox
        ColumnChange                  matlab.ui.control.CheckBox
        GeneralLB                     matlab.ui.control.ListBox
        AllBehaviorsLabel             matlab.ui.control.Label
        MDA                           matlab.ui.control.Button
        Ks                            matlab.ui.control.Spinner
        ofKMeansClustersSpinnerLabel  matlab.ui.control.Label
        PCs                           matlab.ui.control.Spinner
        ofPrincipalComponentsSpinnerLabel  matlab.ui.control.Label
        KMEANSCLUSTERINGVALIDATIONLabel  matlab.ui.control.Label
        PCA                           matlab.ui.control.Button
        pre_standardized              matlab.ui.control.CheckBox
        Standardize                   matlab.ui.control.Button
        STANDARDIZATIONLabel          matlab.ui.control.Label
        Data                          matlab.ui.control.Button
    end

    
    properties (Access = private)
        file % Description
        datastart % Description
       finalweight % Description
        OData % Description
        check % Description
        klusters % Description
        pcnum % Description
        filename % Description
        checkcolumnchange % Description
        Selecteditemsdata
        Selecteditems % Description
        cellnumber
        input_names % Description
        input_datanum % Description
        filen % Description
        excel % Description
        subpanel %description
        proceed %description
        cloading % cell loadings 
        cloadingred % reduced cell loading
        stv % File outline no data
        work % Description
    end
    
  
    

    % Callbacks that handle component events
    methods (Access = private)

        % Value changed function: Active
        function ActiveValueChanged(app, event)
            value = app.Active.Value;
            
        end

        % Button pushed function: Data
        function DataButtonPushed(app, event)
            clear global
            value = app.Data;
            app.file = uigetfile('*');
            figure(app.UIFigure)
            m = msgbox(sprintf('You have selected the raw data file "%s" ',[app.file]), 'Raw data selected');
            uiwait(m)
            figure(app.UIFigure)
            app.Active.Value = app.file;
           
            % File Reading
            raw_data = readcell(app.file); %get data from file 
            r = ~cellfun(@isnumeric,raw_data); %nonnumeric data
            app.stv =   cell(size(raw_data)); %cell matrix size of data
              
             for i = 1:size(raw_data(:,2:end),2)*size(raw_data(:,2:end),1)
                  if r(i) == 0 
                     continue 
                  else
                     app.stv{i} = raw_data{i(r(i))};
                  end
             end
            rows = size(app.stv,1);
            columns = size(app.stv,2);
            raw_data(rows+1:end,:)=[];
            raw_data(:,columns+1:end) = [];
            app.OData = raw_data;

           x = find(strcmpi(raw_data(1,:),'sex')); %locate column labeled sex
           
           % Listbox functions/features
            app.input_names =[];
            app.input_datanum = [];

              for q = find(cellfun(@isnumeric, raw_data(2,2:end))) +1 %locate numeric columns in matrix
                thecells = (raw_data(1,q));
                app.input_names = [app.input_names;{thecells}];
                app.input_datanum = [app.input_datanum, q];
              end
              
             app.input_names = string(app.input_names);
             app.input_datanum = num2cell(app.input_datanum);
             
             for x = 1:length(app.input_names)
            app.cloading{x} = app.input_names{x};
             end
           app.cloading= app.cloading';
         

           %Populate the listbox and associate numeric values for callback
              app.GeneralLB.Items = app.input_names;
              app.GeneralLB.ItemsData = app.input_datanum;
              app.checkcolumnchange = 0;
        end

        % Value changed function: GeneralLB
        function GeneralLBValueChanged2(app, event)
            value = app.GeneralLB.Value;

            if app.checkcolumnchange == 0 
                app.GeneralLB.ItemsData = app.input_datanum;
            end
               
      
           
        end

        % Value changed function: ColumnChange
        function ColumnChangeValueChanged(app, event)
            value = app.ColumnChange.Value;
            app.checkcolumnchange = value;
           
             if app.checkcolumnchange == 1
              set(app.ReducedLB,'Enable','on')  
             end
             
                if app.checkcolumnchange == 0
              set(app.ReducedLB,'Enable','off')  
                end

             %Checkbox enables & disables the Reduced List box
        end

        % Value changed function: ReducedLB
        function ReducedLBValueChanged(app, event)
            value = app.ReducedLB.Value;
            newdata = []; %Empty array to later fill items data
            
            % When data is reduced populate w/ unselected bhvrs from main
            if app.checkcolumnchange == 1
                  f = find(~ismember(string(app.GeneralLB.ItemsData),string(app.GeneralLB.Value)));
                  app.ReducedLB.Items = app.GeneralLB.Items(f);
                  app.ReducedLB.ItemsData = app.GeneralLB.ItemsData(f);
            end

              %Find column title and column then insert within Items data
              app.cloadingred = cell(length(app.ReducedLB.Items),1);
                   for i = 1:length(app.ReducedLB.Items)
                     app.cloadingred{i} = app.ReducedLB.Items{i};
                   end
            
            
        end

        % Button pushed function: Standardize
        function StandardizeButtonPushed(app, event)
            raw_data = readcell(app.file);
            r = ~cellfun(@isnumeric,raw_data);
            app.stv =   cell(size(raw_data));
              
             for i = 1:size(raw_data,2)*size(raw_data,1)

                  if r(i) == 0 
                     continue 
                  else
                     app.stv{i} = raw_data{i(r(i))};
                  end
               
              end
            
            rows = size(app.stv,1);
            columns = size(app.stv,2);
            raw_data(rows+1:end,:)=[];
            raw_data(:,columns+1:end) = [];
            app.OData = raw_data;
            h = waitbar(0,'Data being standardized...'); 
            figure(h)

        
          
          for  wait=1:1000% Used for the load bar
             
             if app.checkcolumnchange == 0 %Using entire data set 

                   for k = 1: length(app.GeneralLB.ItemsData)
                         app.stv(2:end,cell2mat(app.GeneralLB.ItemsData(k)))= num2cell(zscore(cell2mat(app.OData(2:end,cell2mat(app.GeneralLB.ItemsData(k))))));
                   end
                 
             elseif app.checkcolumnchange == 1 %If using reduced data set 

                 for k = 1: length(app.ReducedLB.ItemsData)
                         app.stv(2:end,cell2mat(app.ReducedLB.ItemsData(k)))= num2cell(zscore(cell2mat(app.OData(2:end,cell2mat(app.ReducedLB.ItemsData(k))))));
                 end
                   
             end
             waitbar(wait/1000,h)
          end
          %% Excel File Creation
          [~,app.filen] = fileparts(app.file);
        
        prompt = {'Name your standardized file:'};
        dlgtitle = 'Standardized File Input';
        dims = [1 35];
        definput = strcat({app.filen},'_STDIZED');
        answer = inputdlg(prompt,dlgtitle,dims,definput);

        app.filename = string(answer);
        fileName = char(answer);

        % Adds number to file to prevent duplicates 
        numberSuffix = 1;
        while numberSuffix < 3 % Exit at 500 as a failsafe, just in case all files exist.
      
          if (exist(strcat(pwd,'/PUMBAA Outputs/',app.filename,'.xlsx'), 'file') == 2)
           
            % Construct a new filename.
            fileName = sprintf( '%s',[app.filename,string(numberSuffix)]);%added brackets to concatenate values
            numberSuffix  = numberSuffix  + 1;

          else
            break; % Out of while loop
          end
        end       
        
        %New code to remove columns that are empty
        app.stv(2:end,1) = raw_data(2:end,1); %Add the genotype column from original data set 

        if app.checkcolumnchange == 1 %If using reduced data set remove empty columns 
        app.work = find(cellfun(@isempty,app.stv(2,:)));
        app.stv(:,app.work) = [];
         end

        
        writecell(app.stv,strcat(pwd,'/PUMBAA Outputs/',app.filename,'.xlsx')) ;
        close(figure(h))
        m = msgbox(sprintf('File is under the desired output file name "%s" within the PUMBAA Output Folder',[app.filename]), 'Standardization complete');
        uiwait(m)
        app.Active.Value = strcat(app.filename, '.xlsx');
        

        end

        % Button pushed function: StandardizebySexButton
        function StandardizebySexButtonPushed(app, event)
  raw_data = readcell(app.file);
  class(app.file)
            r = ~cellfun(@isnumeric,raw_data);
            app.stv =   cell(size(raw_data));
              
             for i = 1:size(raw_data,2)*size(raw_data,1)

                  if r(i) == 0 
                     continue 
                  else
                     app.stv{i} = raw_data{i(r(i))};
                  end
               
              end
            
            rows = size(app.stv,1);
            columns = size(app.stv,2);
            raw_data(rows+1:end,:)=[];
            raw_data(:,columns+1:end) = [];
            app.OData = raw_data;
           x = find(strcmpi(raw_data(1,:),'sex')); %locate sex column

if app.checkcolumnchange == 0 
   behaviors = app.GeneralLB.Items;
   itemsdata = app.GeneralLB.ItemsData;
elseif app.checkcolumnchange == 1
   behaviors = app.ReducedLB.Items;
   itemsdata = app.ReducedLB.ItemsData;
end


  sbhvrs= string(behaviors); %create string format of bhvrs
  bhvrl = size(behaviors,2); %length of the bhvrs
            
   fig = figure('Visible','off');

   panel = uipanel('parent',fig,...
    'Title','Choose behaviors to standardize by sex',... 
    'position',[.01 .01 1 .95]);
     box = zeros(bhvrl,1);
     app.subpanel = uipanel('parent',fig,...
          'Title','Choose behaviors to standardize by sex',...
          'position',[.01 .01 1 .95]);
%%%Change width 
for i = 1:bhvrl %Make a checkbox for each behavior
    
    if i <= 15
        box(i,1) = uicontrol('parent',app.subpanel,'style','checkbox',...
            'string',behaviors(i),...
            'position',[20 375-i*25 90 20]);
    else %More than 15 listed behaviors, create 2nd column
        box(i,1) = uicontrol('parent',app.subpanel,'style','checkbox',...
            'string',behaviors(i),...
            'position',[180 375-(i-15)*25 90 20]);
   end

end

%Continue button 
 app.proceed = uicontrol('parent',app.subpanel,'style','pushbutton',...
     'position',[450 20 60 20] , ...
     'BackgroundColor','Green',...
     'Value', 0, ...
     'Callback', @proceedButtonPushed,...
     'String','Continue', ...
     'UserData', 'clicked');

 uiwait %Pause until continue button is pressed

 %% STANDARDIZATION CODE 

     for i = 1:bhvrl

  boxval(i) = get(box(i),'Value'); %get values of checkboxes 

     end

  boxval = logical(boxval'); 
  selected = behaviors(boxval); %index selected values from behaviors
  locate = itemsdata(ismember(string(behaviors),string(selected))); %create list of selected behaviors

  



           set(fig,'Visible','on')

         h = waitbar(0,'Data being standardized...'); 
         figure(h)
          
          for  wait=1:1000
             
             if app.checkcolumnchange == 0 %Using entire data set 

                 for xfactor = (1:length(locate))
                

                     k = locate{xfactor};
                          
                     
                     zoF = num2cell(zscore([raw_data{strcmpi(raw_data(:,x),'female'),k}]'));
                     zoM = num2cell(zscore([raw_data{strcmpi(raw_data(:,x),'male'),k}]'));
                     Fcounter = 0;
                     Mcounter = 0;
                     
                     for r = (2:rows) 
                         stc = strcmpi(raw_data(r,x),'female');
                        
                         if stc == 1
                             Fcounter = Fcounter + 1;
                             app.stv(r,k)=zoF(Fcounter,1);
                         else 
                             Mcounter = Mcounter + 1;
                             app.stv(r,k) = zoM(Mcounter,1);                        
                         end
                     
                     end

                 end
                 rest = setdiff(cell2mat(app.GeneralLB.ItemsData),cell2mat(locate));
                 for lasti = 1:length(rest)%Going through the length of rest to use for loop
                     m = rest(lasti);%Call the actual value based on it's position
                     outcell = cell2mat(raw_data(2:end,m));
                     zoR = zscore(outcell);%Find the z score of the column that wasn't selected
                     zoR = num2cell(zoR);
                     app.stv(2:end,m) = zoR;%place column of values in larger array
                 end
                 
             elseif app.checkcolumnchange == 1 %If using reduced data set 
                     for xfactor = (1:length(app.ReducedLB.Value))
                     k = app.ReducedLB.Value{xfactor};
                     zoF = num2cell(zscore([raw_data{strcmpi(raw_data(:,x),'female'),k}]'));
                     zoM = num2cell(zscore([raw_data{strcmpi(raw_data(:,x),'male'),k}]'));
                     Fcounter = 0;
                     Mcounter = 0;
                       for r = (2:rows)
                         stc = strcmpi(raw_data(r,x),'female');
                         if stc == 1
                             Fcounter = Fcounter + 1;
                             app.stv(r,k)=zoF(Fcounter,1);
                         else 
                             Mcounter = Mcounter + 1;
                             app.stv(r,k) = zoM(Mcounter,1); 
                          end
                        end
                      end
                 rest = setdiff(cell2mat(app.ReducedLB.ItemsData),cell2mat(locate));
                 for lasti = 1:length(rest)%Going through the length of rest to use for loop
                     m = rest(lasti);%Call the actual value based on it's position
                     outcell = cell2mat(raw_data(2:end,m));
                     zoR = zscore(outcell);%Find the z score of the column that wasn't selected
                     zoR = num2cell(zoR);
                     app.stv(2:end,m) = zoR;%place column of values in larger array
                 end
             end
             waitbar(wait/1000,h)
          end

          %% Excel File Creation
          [~,app.filen] = fileparts(app.file);
        
        prompt = {'Name your standardized file:'};
        dlgtitle = '';
        dims = [1 35];
        definput = strcat({app.filen},'_STDIZED');
        opts = 'on';
        answer = inputdlg(prompt,dlgtitle,dims,definput);

        app.filename = string(answer);
        

        % Adds number to file to prevent duplicates 
        numberSuffix = 1;
        while numberSuffix < 3 % Exit at 500 as a failsafe, just in case all files exist.
      
          if (exist(strcat(pwd,'/PUMBAA Outputs/',app.filename,'.xlsx'), 'file') == 2)
              display((exist(strcat(pwd,'/PUMBAA Outputs/',app.filename,'.xlsx'), 'file') == 2))

            % Construct a new filename.
            app.filename = sprintf( '%s',[app.filename,string(numberSuffix)]);%added brackets to concatenate values
            numberSuffix  = numberSuffix  + 1;
         
          else
            break; % Out of while loop
          end
        end    
 

          app.stv(2:end,1) = raw_data(2:end,1); %Add the genotype column from original data set 

         if app.checkcolumnchange == 1
        app.work = find(cellfun(@isempty,app.stv(2,:)));
        app.stv(:,app.work) = [];
         end

       
        writecell(app.stv,strcat(pwd,'/PUMBAA Outputs/',app.filename,'.xlsx')) ;
        close(figure(h))
        m = msgbox(sprintf('File is under the desired output file name "%s" within the PUMBAA Output Folder',app.filename), 'Standardization complete');
        uiwait(m)
        
        app.Active.Value = strcat(app.filename, '.xlsx');
          close all

            
        %% Extra GUI Functions

          %Resume Standardization for Standardize by X 
           function proceedButtonPushed(object, event)
             uiresume
            end


 

        end

        % Value changed function: pre_standardized
        function pre_standardizedValueChanged(app, event)
            app.check = app.pre_standardized.Value;
            if app.check == 1
              set(app.Standardize,'Enable','off')
            end
                if app.check == 0
              set(app.Standardize,'Enable','on')
                end
            
        end

        % Button pushed function: PCA
        function PCAButtonPushed(app, event)
            %%If statememt included if data is either standardized or not

             app.check = 0;
             
        
         PBAoutput = strcat(pwd,'/PUMBAA Outputs/');
       
         
          if app.check == 0
               rawdatax = readcell(strcat(PBAoutput,app.filename,'.xlsx'));
            %rawdatax(app.work) = [];
            r = cellfun(@isnumeric,rawdatax);
            datax =   cell(size(rawdatax));
              for i = 1:size(rawdatax,2)*size(rawdatax,1)
                  if r(i) == 0 
                     continue 
                  else
                     datax{i} = rawdatax{i(r(i))};
                  end
              end
              
              datax = cell2mat(datax);
            columns = size(datax,2);
            trying = (datax(:,2:columns)); % standardized data from excel 
           genotype = datax(:,1); % genotype markers WT=1 , AS=2 
           fileName = app.filename;
           
       
           %%%%%If Data is already standardized
          elseif app.check==1
            rawdatax = readcell(app.file);
            %rawdatax(app.work) = [];
            r = cellfun(@isnumeric,rawdatax);
            datax =   cell(size(rawdatax));
              for i = 1:size(rawdatax,2)*size(rawdatax,1)
                  if r(i) == 0 
                     continue 
                  else
                     datax{i} = rawdatax{i(r(i))};
                  end
              end
            columns = size(datax,2);
            trying = datax(:,2:columns); % standardized data from excel 
            genotype = datax(:,1); % genotype markers WT=1 , AS=2 
             [~,app.filen] = fileparts(app.file);
              fileName = [app.filen,];
          end
         
         
          
    a = ~ismissing(trying(1,:));
    b = a;
    trying = trying(:,b);

if app.checkcolumnchange
    %change the columns in between
end 
      
      %PCA 
      [coeff,score,~,~,explained] = pca(trying);
      coeff = num2cell(coeff);
    
      if app.checkcolumnchange == 0
          loadings = [app.cloading coeff];

      elseif app.checkcolumnchange == 1

          loadings = [app.cloadingred coeff];

      end
      
      %%Needs to be fixed
      
    %Anika Code
    if app.checkcolumnchange == 0 

    numCols = size(app.GeneralLB.Items,2);
    f = cell(1, numCols);
        for c = 1:size(app.GeneralLB.Items,2)
            f{c} = strcat('PC', ' ',num2str(c));
        end

    elseif app.checkcolumnchange == 1

    numCols = size(app.ReducedLB.Items,2);
    f = cell(1, numCols);        
         for c = 1:size(app.ReducedLB.Items,2)
            f{c} = strcat('PC', ' ',num2str(c));
         end
    end
    colData = f.';
    
    %Create cell for data sheet
    cscore = num2cell(score);
    scoresheet = app.stv;
    %scoresheet(:,size(scoresheet,2)) = [];
    scoresheet(2:end,(size(rawdatax,2)-size(score,2))+1:end) = cscore;
    %scoresheet(2:end,1) = num2cell(genotype);
    scoresheet(1,(size(rawdatax,2)-size(score,2)+1:end)) = colData';






    %Scree Values excel file
    titleExp = 'Explained Variance per PC(%)';
    writematrix(explained,strcat(pwd,'/PUMBAA Outputs/', fileName,'_SCREE', '.xlsx'),'Range','B2')
    writecell(colData,strcat(pwd,'/PUMBAA Outputs/',fileName,'_SCREE', '.xlsx'),'Range','A2')
    writematrix(titleExp,strcat(pwd,'/PUMBAA Outputs/',fileName,'_SCREE', '.xlsx'),'Range','B1')
    
    %Loadings Excel File
    writecell(loadings,strcat(pwd,'/PUMBAA Outputs/', fileName,'_LOADINGS ', '.xlsx'),'Range','A2')
    writecell(colData',strcat(pwd,'/PUMBAA Outputs/',fileName,'_LOADINGS', '.xlsx'),'Range','B1')

    %PCA Scores 
           subjects = rawdatax(:,1);
           scoresheet = scoresheet(:,2:end);
           writecell(scoresheet,strcat(pwd,'/PUMBAA Outputs/', fileName,'_PCASCORES ', '.xlsx'),'Range','B1')
           writecell(rawdatax(:,1),strcat(pwd,'/PUMBAA Outputs/', fileName,'_PCASCORES ', '.xlsx'),'Range','A1')
    
    %Scree Plot 
      scree = figure; 
      plot(1:size(score,2),explained,'bd-')
      hold on 
      grid on
      xlabel('Principal Components')
      ylabel('% Variance Explained')
      title('Scree Plot')
      hold off 
      
      str1 = append(pwd,'/PUMBAA Outputs/',fileName,'_SCREE','.fig');
      saveas(scree,str1)

     
        end

        % Value changed function: PCs
        function PCsValueChanged(app, event)
             value = app.PCs.Value;
            app.pcnum = value;
        end

        % Value changed function: Ks
        function KsValueChanged(app, event)
                value = app.Ks.Value;
            app.klusters = value;
        end

        % Button pushed function: MDA
        function MDAButtonPushed(app, event)
            %%If statememt included if data is either standardized or not
        clear global 
        app.check = 0;
         app.filename
          
         if app.check == 0
            
              rawdatax = readcell(strcat([pwd,'/PUMBAA Outputs/'],app.filename));
            r = cellfun(@isnumeric,rawdatax);
            datax =   cell(size(rawdatax));
              for i = 1:size(rawdatax,2)*size(rawdatax,1)
                  if r(i) == 0 
                     continue 
                  else
                     datax{i} = rawdatax{i(r(i))};
                  end
              end
              datax = cell2mat(datax);
            columns = size(datax,2);
            trying = (datax(:,2:columns)); % standardized data from excel  
            genotype = datax(:,1); % genotype markers WT=1 , AS=2 
               a = ~ismissing(trying(1,:));
               b = find(a);
              trying = trying(:,b); %#ok<FNDSB> 
              fileName = app.filename;
         
         elseif app.check == 1
             
              rawdatax = readcell(app.file);
            r = ~cellfun(@isnumeric,rawdatax);
            datax =   cell(size(rawdatax));
              for i = 1:size(rawdatax,2)*size(rawdatax,1)
                  if r(i) == 0 
                     continue 
                  else
                     datax{i} = rawdatax{i(r(i))};
                  end
              end
              cell2mat(datax)
            columns = size(datax,2);
            trying = datax(:,2:columns); % standardized data from excel 
            genotype = datax(:,1); % genotype markers WT=1 , AS=2 
           [~,app.filen] = fileparts(app.file);
          fileName = [app.filen,];
          exceltype= '.xlsx';
          end
     
      
      %PCA
      [coeff,score] = pca(trying);
     % kmeans clustering
     x = score(:,1:app.pcnum);

           %rng(1);
           [clusters,Cr, ~, Distance] = kmeans(score(:,1:app.pcnum),app.klusters);
          % Maximizing accuracy 
           samplecorrect = 100*(sum(clusters == genotype)-1)./...
           (length(clusters == genotype)-1); 
           
           % Take the clusters and flip it into newclusters 
           
           for x = 1 : length(clusters) 
                if clusters(x) == 1
                    newclusters(x) = 2;
                elseif clusters(x) == 2
                    newclusters(x) = 1;
                end
            end
            newclusters = newclusters' ;

      if samplecorrect > 100*(sum(newclusters == genotype)-1) / (length(newclusters == genotype)-1)
         for x = 1
             continue 
         end
      else
          clusters = newclusters;
          samplecorrect = 100*(sum(newclusters == genotype)-1) / (length(newclusters == genotype)-1);
      end

            xc = Cr(1,1);           
            xc1 = Cr(2,1);

           if (app.pcnum == 1)
            distance = abs(xc - xc1);
            centroid = [{''},'X-Value'; 'Center of Cluster 1',string(xc); 'Center of Cluster 2', string(xc1); 'Distance between Centroids', string(distance)];
           end
           
            if (app.pcnum == 2)
                yc = Cr(1,2);
                yc1 = Cr(2,2);
                distance = abs(sqrt((xc - xc1) .^2 + (yc - yc1) .^2));
                centroid = [{''},'X-Value','Y-Value'; 'Center of AS Cluster',string(xc), string(yc); 'Center of WT Cluster', string(xc1), string(yc1); 'Distance between Centroids', string(distance), {''}];
            end
            
            if (app.pcnum >= 3)
                yc = Cr(1,2);
                yc1 = Cr(2,2);
                zc = Cr(1,3);
                zc1 = Cr(2,3);
                distance = abs(sqrt((xc - xc1) .^2 + (yc - yc1) .^2 + (zc-zc1) .^2));
                centroid = [{''},'X-Value','Y-Value','Z-Value'; 'Center of AS Cluster',string(xc), string(yc), string(zc); 'Center of WT Cluster', string(xc1), string(yc1), string(zc1); 'Distance between Centroids', string(distance), {''}, {''}];
            end
            
     % clustering accuracy

         %while samplecorrect < 50
          % clusters = kmeans(score(:,1:app.pcnum-1),app.klusters);
         %  samplecorrect = 100*(sum(clusters == genotype)-1)./...
          % (length(clusters == genotype)-1);
        % end

             complete = msgbox('Principal Component Analysis and K-Means Clustering is Completed');
            uiwait(complete)
        
            accuracy = sprintf("Accuracy is %.2f.\n",samplecorrect)
            centrDist = sprintf("Distance between centroids is %.2f.\n", distance)
            accpop = msgbox(accuracy + centrDist)
            uiwait(accpop)  


            variables = rawdatax(1,:);
            variables = variables(2:end-1);
            display(variables)

         if app.check == 0 
           numCols = size(app.GeneralLB.Items,2);
            d = cell(1, numCols);


             for c = 1:size(app.GeneralLB.Items,2)
                d{c} = strcat('PC', ' ',num2str(c));
             end
             
         elseif app.check == 1
             numCols = size(app.ReducedLB.Items,2);
            d = cell(1, numCols); 
             for c = 1:size(app.ReducedLB.Items,2)
            d{c} = strcat('PC', ' ',num2str(c));
             end
         end

            text1 = '# of Principal Components Used';
            numopc = string(app.pcnum);
            trans = transpose(variables);

            %Data Validation File (% Correct & Centroid Distance)
            writematrix(centroid,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Centroid Data')
            writematrix(text1,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Centroid Data', 'Range', 'A6')
            writematrix(numopc,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Centroid Data', 'Range','B6')
            writematrix(samplecorrect,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Percent Correct')
            writematrix(text1,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Percent Correct', 'Range','A6')
            writematrix(numopc,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'), 'Sheet','Percent Correct', 'Range','B6')
          
            %Correct cluster displays 1, incorrect cluster displays 0
            gene = rawdatax(2:end,1);
            correct = zeros(1,length(rawdatax(:,1)));
            cls = num2cell(clusters);
            for w = 1:length(gene)
                if (isequal(gene(w), cls(w)))
                    correct(w) = 1;
                else
                    correct(w) = 0;
                end
            end
            dispcorr = correct(1:end-1);
          
            writecell(rawdatax(:,2),strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'),'Sheet','Validation Plot')
            writecell(rawdatax(:,1),strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'),'Sheet','Validation Plot','Range','B1')
            writematrix('Cluster',strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION', '_PC',numopc,'.xlsx'),'Sheet','Validation Plot','Range','C1')
            writematrix(clusters,strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION', '_PC',numopc,'.xlsx'),'Sheet','Validation Plot','Range','C2')
            writematrix('Correct',strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'),'Sheet','Validation Plot','Range','D1')
            writematrix(dispcorr',strcat(pwd,'/PUMBAA Outputs/', fileName,'_VALIDATION','_PC',numopc, '.xlsx'),'Sheet','Validation Plot','Range','D2')

%             writecell(subjects,strcat(pwd,'\PUMBAA Outputs\', fileName,'_Silhouette Plot ', '.xlsx'),'Range','A1')
%             %Silhouette Plots
%            silhouette(score(:,1:app.pcnum),clusters);
%            avgVal = mean(silhouette(score(:,1:app.pcnum),clusters));
%            writematrix(silhouette(score(:,1:app.pcnum),clusters), strcat(pwd,'\PUMBAA Outputs\', fileName,'_Silhouette Plot ','.xlsx'),'Range','B2')
%            writematrix('Silhouette Values', strcat(pwd,'\PUMBAA Outputs\',fileName,'_Silhouette Plot ','.xlsx'),'Range','B1')
%            writematrix(avgVal, strcat(pwd,'\PUMBAA Outputs\',fileName,'_Silhouette Plot ','.xlsx'),'Range','D2')
%            writematrix([pwd,'\PUMBAA Outputs\','Average Silhouette Value', 'Silhouette Plot ', fileName, '.xlsx'], 'Range', 'D1')
     
%Point Distance from Centroids
     %      score(:,1:app.pcnum) = data2
     %      meanDistances = zero(app.klusters ,1);
     %      for k = 1 : app.klusters 
     %          % get the x and the y of the centroids 
     %          xc = Cr(k ,1);
     %          yc = Cr(k ,2);
     %          % get x and y coordinates of points within this class only 
     %          inClass = clusters == k; % indexes of points that were assigned to this class 
     %          x = data2(inClass, 1);
     %          y = data2(inClass, 2);
     %          %get distances of all points in the class to the centroid for this class 
     %          distances = sqrt((x - xc) .^2 + (y - yc) .^2);
     %          meanDistances(k) = mean(distances);
     %      end
     %      ptocentroid = msgbox(sprintf("The mean distance from the points in
     %      the cluster to the centroid is", meanDistances(k));
     %      uiwait(ptocentroid)

%% PLOTS

% Saving PCA output as variables to plot (and potentially export)
WTclusPC1 = score(clusters == 1,1);
WTclusPC2 = score(clusters == 1,2);
ASclusPC1 = score(clusters == 2,1);
ASclusPC2 = score(clusters == 2,2);

WTgenoPC1 = score(genotype == 1,1);
WTgenoPC2 = score(genotype == 1,2);
ASgenoPC1 = score(genotype == 2,1);
ASgenoPC2 = score(genotype == 2,2);

%Validation values
Wlength = length(WTgenoPC1);
PC1 = score(:,1); %this is PC1 value, first column of score
PC2 = score(:,2);
INDEX = clusters~=genotype; % logical array of incorrect values
INDEXWT = INDEX(1:Wlength); %index all WT positions
INDEXAS = INDEX(Wlength+1:length(genotype)); %index all AS positions
% use length of WT incorrect values to index the PC1 values from genotype vector
Windex1=WTgenoPC1(INDEXWT);
Windex2=WTgenoPC2(INDEXWT);
Aindex1=ASgenoPC1(INDEXAS);
Aindex2=ASgenoPC2(INDEXAS);
  
  if app.pcnum == 1 %Plot in 1 PC

     pca1 = figure
    
plot(WTclusPC1,1,'k.','MarkerSize',14)
    % plot the WT clusters (PC1 where clusters = 1,PC2 where clusters = 1)
hold on 
grid on 
plot(ASclusPC1,1,'r.','MarkerSize',14)
    % plot the AS clusters (PC1 where clusters = 2,PC2 where clusters = 2)
hold on
grid on
plot(Windex1,1,'c.','MarkerSize',14)
    % plot the ID of incorrect PC1 and PC2 values over the correct ones 
hold on
grid on
plot(Aindex1,1,'c.','MarkerSize',14)
hold on
grid on
plot(Cr(:,1),1,'bx','MarkerSize',16,'Linewidth',2)


xlabel('PC1')
title(sprintf("PCA with Validation, Percent Correct: %.2f.\n",samplecorrect) + sprintf("Distance between Centroids: %.2f\n", distance))
legend('Group 1, Correct','Group 2, Correct','Incorrect','Location','Best')
hold off
fprintf('Accuracy is %.2f.\n',samplecorrect)
str1 = append(pwd,'/PUMBAA Outputs/',fileName,'VALIDATION_PC',numopc, '.fig'); %%%%%!!!!!
saveas(pca1,str1)

  

  elseif app.pcnum == 2


%%%%%%%%% Validation Plot- PC2
pca2 = figure
plot(WTclusPC1,WTclusPC2,'k.','MarkerSize',14)
    % plot the WT clusters (PC1 where clusters = 1,PC2 where clusters = 1)
hold on 
grid on 
plot(ASclusPC1,ASclusPC2,'r.','MarkerSize',14)
    % plot the AS clusters (PC1 where clusters = 2,PC2 where clusters = 2)
hold on
grid on
plot(Windex1, Windex2, 'c.','MarkerSize',14)
    % plot the ID of incorrect PC1 and PC2 values over the correct ones 
hold on
grid on
plot(Aindex1, Aindex2, 'c.','MarkerSize',14)
hold on
grid on
plot(Cr(:,1),Cr(:,2),'bx','MarkerSize',16,'Linewidth',2)
xlabel('PC1')
ylabel('PC2')
title(sprintf("PCA with Validation, Percent Correct: %.2f.\n",samplecorrect) + sprintf("Distance between Centroids: %.2f\n", distance))
legend('Group 1, Correct','Group 2, Correct','Incorrect','Location','Best')
hold off
fprintf('Accuracy is %.2f.\n',samplecorrect)
str2 = append(pwd,'/PUMBAA Outputs/',fileName,'VALIDATION_PC',numopc, '.fig');
saveas(pca2,str2)

  elseif app.pcnum > 2
  WTclusPC3 = score(clusters == 1,3);
  ASclusPC3 = score(clusters == 2,3);
  WTgenoPC3 = score(genotype == 1,3);
  ASgenoPC3 = score(genotype == 2,3);
  
  Windex3=WTgenoPC3(INDEXWT);
  Aindex3=ASgenoPC3(INDEXAS);

%%%%%%% Validation Plot
pca3 = figure
plot3(WTclusPC1,WTclusPC2,WTclusPC3,'k.','MarkerSize',14)
    % plot the WT clusters (PC1 where clusters = 1,PC2 where clusters = 1)
hold on 
grid on 
plot3(ASclusPC1,ASclusPC2,ASclusPC3,'r.','MarkerSize',14)
    % plot the AS clusters (PC1 where clusters = 2,PC2 where clusters = 2)
hold on
grid on
plot3(Windex1, Windex2,Windex3, 'c.','MarkerSize',14)
    % plot the ID of incorrect PC1 and PC2 values over the correct ones 
hold on
grid on
plot3(Aindex1, Aindex2,Aindex3, 'c.','MarkerSize',14)
hold on 
grid on 
plot3(Cr(:,1),Cr(:,2),Cr(:,3),'bx','MarkerSize',16,'Linewidth',2)
hold on 
grid on
xlabel('PC1')
ylabel('PC2')
title(sprintf("PCA with Validation, Percent Correct: %.2f.\n",samplecorrect) + sprintf("Distance between Centroids: %.2f\n", distance))
legend('Group 1, Correct','Group 2, Correct','Incorrect','Location','Best')
hold off 
str3 = append(pwd,'/PUMBAA Outputs/',fileName,'VALIDATION_PC',numopc, '.fig');
saveas(pca3,str3)
  end

  %% Approximation and Genotype Plots

  %%%%%%%% Aproximation plot-PC2 2
% figure
% plot(WTclusPC1,WTclusPC2,'k.','MarkerSize',14)
%     % plot the WT clusters (PC1 where clusters = 1,PC2 where clusters = 1)
% hold on 
% grid on 
% plot(ASclusPC1,ASclusPC2,'r.','MarkerSize',14)
%     % plot the AS clusters (PC1 where clusters = 2,PC2 where clusters = 2)
% xlabel('PC1')
% ylabel('PC2')
% title('PCA with Clusters')
% legend('WT','AS','Location','Best')
% hold off 
% 
% %%%%%%%%% Genotype plot-PC2
% figure
% plot(WTgenoPC1,WTgenoPC2,'k.','MarkerSize',14)
% hold on
% grid on
% plot(ASgenoPC1,ASgenoPC2,'r.','MarkerSize',14)
% legend('WT','AS','Location','Best')
% hold off 
% xlabel('PC1')
% ylabel('PC2')
% title('PCA with Genotype') 

  %%%%%%%%% Approximation - PC3
% figure
% plot3(WTclusPC1, WTclusPC2,WTclusPC3,'k.','MarkerSize',14)
%  %plot WT clusters (PC1:Clusters =1, PC2:clusters =2, PC3:cluster=3
% hold on
% grid on
% plot3(ASclusPC1,ASclusPC2,ASclusPC3,'r.','MarkerSize',14)
% 
% xlabel('PC1')
% ylabel('PC2')
% zlabel('PC3')
% title('PCA with Clusters')
% legend('WT,Correct','AS,Correct','Location','Best')
% 
% %%%%%%%% Genotype plot - PC3
% figure
% plot3(WTgenoPC1,WTgenoPC2,WTgenoPC3,'k.','MarkerSize',14)
% hold on
% grid on
% plot3(ASgenoPC1,ASgenoPC2,ASgenoPC3,'r.','MarkerSize',14)
% legend('WT,Correct','AS,Correct','Location','Best')
% hold off 
% xlabel('PC1')
% ylabel('PC2')
% zlabel('PC3')
% title('PCA with Genotype')
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 639 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create Panel
            app.Panel = uipanel(app.UIFigure);
            app.Panel.Title = 'PUMBAA';
            app.Panel.Position = [1 1 640 480];

            % Create Data
            app.Data = uibutton(app.Panel, 'push');
            app.Data.ButtonPushedFcn = createCallbackFcn(app, @DataButtonPushed, true);
            app.Data.Position = [110 391 440 22];
            app.Data.Text = 'Load Data';

            % Create STANDARDIZATIONLabel
            app.STANDARDIZATIONLabel = uilabel(app.Panel);
            app.STANDARDIZATIONLabel.HorizontalAlignment = 'center';
            app.STANDARDIZATIONLabel.FontWeight = 'bold';
            app.STANDARDIZATIONLabel.Position = [9 362 123 22];
            app.STANDARDIZATIONLabel.Text = {'STANDARDIZATION:'; ''};

            % Create Standardize
            app.Standardize = uibutton(app.Panel, 'push');
            app.Standardize.ButtonPushedFcn = createCallbackFcn(app, @StandardizeButtonPushed, true);
            app.Standardize.Position = [111 154 210 23];
            app.Standardize.Text = 'Standardize Data';

            % Create pre_standardized
            app.pre_standardized = uicheckbox(app.Panel);
            app.pre_standardized.ValueChangedFcn = createCallbackFcn(app, @pre_standardizedValueChanged, true);
            app.pre_standardized.Text = 'Data is already standardized';
            app.pre_standardized.WordWrap = 'on';
            app.pre_standardized.Position = [237 343 186 30];

            % Create PCA
            app.PCA = uibutton(app.Panel, 'push');
            app.PCA.ButtonPushedFcn = createCallbackFcn(app, @PCAButtonPushed, true);
            app.PCA.Position = [111 119 440 23];
            app.PCA.Text = 'Principal Component Analysis';

            % Create KMEANSCLUSTERINGVALIDATIONLabel
            app.KMEANSCLUSTERINGVALIDATIONLabel = uilabel(app.Panel);
            app.KMEANSCLUSTERINGVALIDATIONLabel.FontWeight = 'bold';
            app.KMEANSCLUSTERINGVALIDATIONLabel.Position = [9 87 236 22];
            app.KMEANSCLUSTERINGVALIDATIONLabel.Text = 'K-MEANS CLUSTERING & VALIDATION:';

            % Create ofPrincipalComponentsSpinnerLabel
            app.ofPrincipalComponentsSpinnerLabel = uilabel(app.Panel);
            app.ofPrincipalComponentsSpinnerLabel.HorizontalAlignment = 'right';
            app.ofPrincipalComponentsSpinnerLabel.Position = [109 57 146 22];
            app.ofPrincipalComponentsSpinnerLabel.Text = '# of Principal Components';

            % Create PCs
            app.PCs = uispinner(app.Panel);
            app.PCs.Limits = [0 5];
            app.PCs.ValueChangedFcn = createCallbackFcn(app, @PCsValueChanged, true);
            app.PCs.Position = [274 57 49 22];

            % Create ofKMeansClustersSpinnerLabel
            app.ofKMeansClustersSpinnerLabel = uilabel(app.Panel);
            app.ofKMeansClustersSpinnerLabel.HorizontalAlignment = 'right';
            app.ofKMeansClustersSpinnerLabel.Position = [358 57 124 22];
            app.ofKMeansClustersSpinnerLabel.Text = '# of K-Means Clusters';

            % Create Ks
            app.Ks = uispinner(app.Panel);
            app.Ks.Limits = [0 3];
            app.Ks.ValueChangedFcn = createCallbackFcn(app, @KsValueChanged, true);
            app.Ks.Position = [501 57 47 22];

            % Create MDA
            app.MDA = uibutton(app.Panel, 'push');
            app.MDA.ButtonPushedFcn = createCallbackFcn(app, @MDAButtonPushed, true);
            app.MDA.Position = [115 15 440 22];
            app.MDA.Text = 'Complete Multidimensional Analysis';

            % Create AllBehaviorsLabel
            app.AllBehaviorsLabel = uilabel(app.Panel);
            app.AllBehaviorsLabel.HorizontalAlignment = 'center';
            app.AllBehaviorsLabel.Position = [166 303 104 22];
            app.AllBehaviorsLabel.Text = 'All Behaviors';

            % Create GeneralLB
            app.GeneralLB = uilistbox(app.Panel);
            app.GeneralLB.Multiselect = 'on';
            app.GeneralLB.ValueChangedFcn = createCallbackFcn(app, @GeneralLBValueChanged2, true);
            app.GeneralLB.Position = [140 198 157 106];
            app.GeneralLB.Value = {'Item 1'};

            % Create ColumnChange
            app.ColumnChange = uicheckbox(app.Panel);
            app.ColumnChange.ValueChangedFcn = createCallbackFcn(app, @ColumnChangeValueChanged, true);
            app.ColumnChange.Text = '';
            app.ColumnChange.Position = [131 177 26 22];

            % Create ReducedLB
            app.ReducedLB = uilistbox(app.Panel);
            app.ReducedLB.Multiselect = 'on';
            app.ReducedLB.ValueChangedFcn = createCallbackFcn(app, @ReducedLBValueChanged, true);
            app.ReducedLB.Enable = 'off';
            app.ReducedLB.Position = [362 198 161 106];
            app.ReducedLB.Value = {'Item 1'};

            % Create SelectedBehaviorsLabel
            app.SelectedBehaviorsLabel = uilabel(app.Panel);
            app.SelectedBehaviorsLabel.Position = [156 177 155 22];
            app.SelectedBehaviorsLabel.Text = 'Exclude Selected Behaviors';

            % Create StandardizebySexButton
            app.StandardizebySexButton = uibutton(app.Panel, 'push');
            app.StandardizebySexButton.ButtonPushedFcn = createCallbackFcn(app, @StandardizebySexButtonPushed, true);
            app.StandardizebySexButton.Position = [343 154 207 23];
            app.StandardizebySexButton.Text = 'Standardize by Sex';

            % Create ActiveFileLabel
            app.ActiveFileLabel = uilabel(app.Panel);
            app.ActiveFileLabel.BackgroundColor = [0.9412 0.9412 0.9412];
            app.ActiveFileLabel.HorizontalAlignment = 'right';
            app.ActiveFileLabel.Position = [202 425 64 22];
            app.ActiveFileLabel.Text = 'Active File:';

            % Create Active
            app.Active = uitextarea(app.Panel);
            app.Active.ValueChangedFcn = createCallbackFcn(app, @ActiveValueChanged, true);
            app.Active.Editable = 'off';
            app.Active.BackgroundColor = [0.9412 0.9412 0.9412];
            app.Active.Tooltip = {'The file being acted on will be displayed in the text box'};
            app.Active.Position = [281 422 180 27];

            % Create RemainingBehaviorsLabel
            app.RemainingBehaviorsLabel = uilabel(app.Panel);
            app.RemainingBehaviorsLabel.Position = [383 303 120 22];
            app.RemainingBehaviorsLabel.Text = 'Remaining Behaviors';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = PUMBAA_v2_1

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end